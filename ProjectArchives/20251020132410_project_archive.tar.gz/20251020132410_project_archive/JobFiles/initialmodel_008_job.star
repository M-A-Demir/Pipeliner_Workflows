
# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_job

_rlnJobTypeLabel    relion.initialmodel
 
_rlnJobIsContinue    0
 
_rlnJobIsTomo    0
 

# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_joboptions_values

loop_ 
_rlnJobOptionVariable #1 
_rlnJobOptionValue #2 
ctf_intact_first_peak           No 
do_combine_thru_disc           No 
do_ctf_correction          Yes 
     do_pad1           No 
do_parallel_discio          Yes 
do_preread_images           No 
    do_queue           No 
   do_run_C1          Yes 
  do_solvent          Yes 
     fn_cont           "" 
      fn_img Select/job007/particles.star 
     gpu_ids           "" 
min_dedicated            1 
  nr_classes            2 
     nr_iter          100 
     nr_pool           30 
  nr_threads           30 
offset_range          6.0 
 offset_step          2.0 
  other_args           "" 
particle_diameter        350.0 
        qsub         qsub 
  qsubscript           "" 
   queuename      openmpi 
    sampling '15 degrees' 
 scratch_dir           "" 
skip_gridding          Yes 
    sym_name           D2 
   tau_fudge          4.0 
     use_gpu          Yes 
 
