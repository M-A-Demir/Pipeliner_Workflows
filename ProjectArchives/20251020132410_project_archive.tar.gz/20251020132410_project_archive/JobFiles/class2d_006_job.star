
# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_job

_rlnJobTypeLabel    relion.class2d.em
 
_rlnJobIsContinue    0
 
_rlnJobIsTomo    0
 

# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_joboptions_values

loop_ 
_rlnJobOptionVariable #1 
_rlnJobOptionValue #2 
allow_coarser           No 
ctf_intact_first_peak           No 
   do_center          Yes 
do_combine_thru_disc           No 
do_ctf_correction          Yes 
       do_em          Yes 
     do_grad           No 
do_parallel_discio          Yes 
do_preread_images           No 
    do_queue           No 
do_zero_mask          Yes 
dont_skip_align          Yes 
     fn_cont           "" 
      fn_img Extract/job005/particles.star 
     gpu_ids           "" 
highres_limit         -1.0 
min_dedicated            1 
 mpi_command 'mpirun -n XXXmpinodesXXX' 
  nr_classes           50 
  nr_iter_em           25 
      nr_mpi           12 
     nr_pool           30 
  nr_threads           30 
offset_range          5.0 
 offset_step          1.0 
  other_args           "" 
particle_diameter        350.0 
psi_sampling          6.0 
        qsub         qsub 
  qsubscript           "" 
   queuename      openmpi 
 scratch_dir           "" 
   tau_fudge          2.0 
     use_gpu          Yes 
 
