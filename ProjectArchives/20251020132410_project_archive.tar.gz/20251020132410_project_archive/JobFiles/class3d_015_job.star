
# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_job

_rlnJobTypeLabel    relion.class3d
 
_rlnJobIsContinue    0
 
_rlnJobIsTomo    0
 

# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_joboptions_values

loop_ 
_rlnJobOptionVariable #1 
_rlnJobOptionValue #2 
allow_coarser           No 
ctf_intact_first_peak           No 
    do_blush          Yes 
do_combine_thru_disc           No 
do_ctf_correction          Yes 
do_fast_subsets           No 
do_local_ang_searches           No 
     do_pad1           No 
do_parallel_discio          Yes 
do_preread_images           No 
    do_queue           No 
do_zero_mask          Yes 
dont_skip_align          Yes 
     fn_cont           "" 
      fn_img Select/job014/particles.star 
     fn_mask           "" 
      fn_ref InitialModel/job008/initial_model.mrc 
     gpu_ids           "" 
highres_limit         -1.0 
    ini_high         50.0 
min_dedicated            1 
 mpi_command 'mpirun -n 10' 
  nr_classes            4 
     nr_iter           25 
      nr_mpi           10 
     nr_pool           30 
  nr_threads           30 
offset_range          5.0 
 offset_step          1.0 
  other_args           "" 
particle_diameter        350.0 
        qsub         qsub 
  qsubscript           "" 
   queuename      openmpi 
ref_correct_greyscale          Yes 
    sampling '7.5 degrees' 
 scratch_dir           "" 
sigma_angles          5.0 
skip_gridding          Yes 
    sym_name           C1 
   tau_fudge          4.0 
     use_gpu          Yes 
 
