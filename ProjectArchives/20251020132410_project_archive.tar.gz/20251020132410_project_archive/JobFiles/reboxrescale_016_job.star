
# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_job

_rlnJobTypeLabel    relion.map_utilities.rebox_rescale_map
 
_rlnJobIsContinue    0
 
_rlnJobIsTomo    0
 

# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_joboptions_values

loop_ 
_rlnJobOptionVariable #1 
_rlnJobOptionValue #2 
    box_size          360 
    do_queue           No 
    do_rebox          Yes 
  do_rescale          Yes 
force_pixel_size          Yes 
   input_map Class3D/job015/run_it025_class001.mrc 
min_dedicated            1 
        qsub         qsub 
  qsubscript           "" 
   queuename      openmpi 
rescale_angpix         1.18 
 
