
# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_job

_rlnJobTypeLabel    relion.extract
 
_rlnJobIsContinue    0
 
_rlnJobIsTomo    0
 

# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_joboptions_values

loop_ 
_rlnJobOptionVariable #1 
_rlnJobOptionValue #2 
 bg_diameter          300 
  black_dust         -1.0 
coords_suffix AutoPick/job004/autopick.star 
  do_float16          Yes 
do_fom_threshold           No 
   do_invert          Yes 
     do_norm          Yes 
    do_queue           No 
 do_recenter           No 
do_reextract           No 
  do_rescale          Yes 
do_reset_offsets           No 
extract_size          360 
fndata_reextract           "" 
min_dedicated            1 
minimum_pick_fom          0.0 
 mpi_command 'mpirun -n 8' 
      nr_mpi            8 
  other_args           "" 
        qsub         qsub 
  qsubscript           "" 
   queuename      openmpi 
  recenter_x            0 
  recenter_y            0 
  recenter_z            0 
     rescale           90 
   star_mics CtfFind/job003/micrographs_ctf.star 
  white_dust         -1.0 
 
