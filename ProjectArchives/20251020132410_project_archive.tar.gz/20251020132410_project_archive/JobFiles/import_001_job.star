
# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_job

_rlnJobTypeLabel    relion.import.movies
 
_rlnJobIsContinue    0
 
_rlnJobIsTomo    0
 

# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_joboptions_values

loop_ 
_rlnJobOptionVariable #1 
_rlnJobOptionValue #2 
          Cs          2.7 
          Q0          0.1 
      angpix          1.4 
  beamtilt_x          0.0 
  beamtilt_y          0.0 
    do_other           No 
    do_queue           No 
      do_raw          Yes 
   fn_in_raw Movies/*.tiff 
      fn_mtf           "" 
is_multiframe          Yes 
is_synthetic           No 
          kV          300 
min_dedicated            1 
onedep_metadata_file           "" 
optics_group_name opticsGroup1 
        qsub         qsub 
  qsubscript           "" 
   queuename      openmpi 
validate_output          Yes 
 
