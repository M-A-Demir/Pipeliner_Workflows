
# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_job

_rlnJobTypeLabel    relion.select.onvalue
 
_rlnJobIsContinue    0
 
_rlnJobIsTomo    0
 

# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_joboptions_values

loop_ 
_rlnJobOptionVariable #1 
_rlnJobOptionValue #2 
do_class_ranker           No 
  do_discard           No 
    do_queue           No 
  do_regroup           No 
do_remove_duplicates           No 
do_select_values          Yes 
    do_split           No 
     fn_data Class2D/job006/run_it025_data.star 
      fn_mic           "" 
    fn_model           "" 
image_angpix         -1.0 
min_dedicated            1 
   nr_groups           20 
  other_args           "" 
        qsub         qsub 
  qsubscript           "" 
   queuename      openmpi 
select_label rlnMaxValueProbDistribution 
select_maxval       9999.0 
select_minval         0.12 
 
