
# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_job

_rlnJobTypeLabel    cryolo.autopick
 
_rlnJobIsContinue    0
 
_rlnJobIsTomo    0
 

# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_joboptions_values

loop_ 
_rlnJobOptionVariable #1 
_rlnJobOptionValue #2 
JANNI_model_path           "" 
    box_size          360 
confidence_threshold          0.3 
 config_file           "" 
    do_queue           No 
        gpus           "" 
  input_file CtfFind/job003/micrographs_ctf.star 
min_dedicated            1 
  model_path /home/efv97572/betagal_workflow/gmodel_phosnet_202005_N63_c17.h5 
  nr_threads           -1 
  other_args           "" 
        qsub         qsub 
  qsubscript           "" 
   queuename      openmpi 
use_JANNI_denoise           No 
 
