
# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_job

_rlnJobTypeLabel    relion.select.interactive
 
_rlnJobIsContinue    0
 
_rlnJobIsTomo    0
 

# version 50001
# CCP-EM Pipeliner version 1.4.0b2

data_joboptions_values

loop_ 
_rlnJobOptionVariable #1 
_rlnJobOptionValue #2 
do_class_ranker           No 
  do_discard           No 
    do_queue           No 
 do_recenter          Yes 
  do_regroup           No 
do_remove_duplicates           No 
do_select_values           No 
    do_split           No 
     fn_data           "" 
      fn_mic           "" 
    fn_model Class3D/job009/run_it025_optimiser.star 
image_angpix         -1.0 
min_dedicated            1 
   nr_groups           20 
  other_args           "" 
        qsub         qsub 
  qsubscript           "" 
   queuename      openmpi 
 
