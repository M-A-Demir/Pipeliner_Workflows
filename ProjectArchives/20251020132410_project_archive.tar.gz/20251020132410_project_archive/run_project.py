#!/usr/bin/env python3
from pipeliner.api.manage_project import PipelinerProject

proj = PipelinerProject(make_new_project=True)
import_001 = proj.schedule_job("JobFiles/import_001_job.star")
motioncorr_002 = proj.schedule_job("JobFiles/motioncorr_002_job.star")
ctffind_003 = proj.schedule_job("JobFiles/ctffind_003_job.star")
autopick_004 = proj.schedule_job("JobFiles/autopick_004_job.star")
extract_005 = proj.schedule_job("JobFiles/extract_005_job.star")
class2d_006 = proj.schedule_job("JobFiles/class2d_006_job.star")
select_007 = proj.schedule_job("JobFiles/select_007_job.star")
initialmodel_008 = proj.schedule_job("JobFiles/initialmodel_008_job.star")
class3d_009 = proj.schedule_job("JobFiles/class3d_009_job.star")
select_010 = proj.schedule_job("JobFiles/select_010_job.star")
class3d_011 = proj.schedule_job("JobFiles/class3d_011_job.star")
select_012 = proj.schedule_job("JobFiles/select_012_job.star")
class3d_013 = proj.schedule_job("JobFiles/class3d_013_job.star")
select_014 = proj.schedule_job("JobFiles/select_014_job.star")
class3d_015 = proj.schedule_job("JobFiles/class3d_015_job.star")
reboxrescale_016 = proj.schedule_job("JobFiles/reboxrescale_016_job.star")

proj.run_scheduled_job(import_001)
proj.wait_for_job_to_finish(import_001, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(motioncorr_002)
proj.wait_for_job_to_finish(motioncorr_002, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(ctffind_003)
proj.wait_for_job_to_finish(ctffind_003, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(autopick_004)
proj.wait_for_job_to_finish(autopick_004, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(extract_005)
proj.wait_for_job_to_finish(extract_005, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(class2d_006)
proj.wait_for_job_to_finish(class2d_006, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(select_007)
proj.wait_for_job_to_finish(select_007, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(initialmodel_008)
proj.wait_for_job_to_finish(initialmodel_008, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(class3d_009)
proj.wait_for_job_to_finish(class3d_009, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(select_010)
proj.wait_for_job_to_finish(select_010, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(class3d_011)
proj.wait_for_job_to_finish(class3d_011, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(select_012)
proj.wait_for_job_to_finish(select_012, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(class3d_013)
proj.wait_for_job_to_finish(class3d_013, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(select_014)
proj.wait_for_job_to_finish(select_014, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(class3d_015)
proj.wait_for_job_to_finish(class3d_015, error_on_fail=True, error_on_abort=True)

proj.run_scheduled_job(reboxrescale_016)
proj.wait_for_job_to_finish(reboxrescale_016, error_on_fail=True, error_on_abort=True)
